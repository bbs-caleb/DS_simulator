print("Data preprocessing completed!")
