import streamlit as st
import os
from supabase import create_client, Client
from supabase.lib.client_options import ClientOptions

# Заголовок для тестового стенда
st.title("RAG Тестовый Стенд")

# Поля ввода для Supabase URL и ключа
supabase_url = st.text_input("SUPABASE_URL", value=os.getenv("SUPABASE_URL", ""))
supabase_key = st.text_input("SUPABASE_KEY", value=os.getenv("SUPABASE_KEY", ""))

# Проверяем, что URL и ключ не пустые
if supabase_url and supabase_key:
    # Создаем клиент Supabase
    supabase: Client = create_client(
        supabase_url,
        supabase_key,
        options=ClientOptions(
            schema="public",
        ),
    )

    # Поле ввода для запроса
    query = st.text_input("Query", "", max_chars=500)
    top = st.number_input("Top", value=3, min_value=1, max_value=5)

    # Если введен запрос, то вызываем RPC функцию rag
    if query:
        # Получаем ключ для OpenAI API
        openai_key = os.getenv("OPENAI_API_KEY", "")

        if not openai_key:
            st.error(
                "Необходимо установить переменную окружения OPENAI_API_KEY для работы с OpenAI."
            )
        else:
            # Вызываем RPC функцию rag
            try:
                response = supabase.rpc(
                    "rag",
                    {
                        "query": query,
                        "top": top,  # Например, мы запрашиваем 5 лучших чанков
                        "openai_key": openai_key,
                    },
                ).execute()

                result_text = response.data["result"]

                # Выводим результат в виде Markdown
                st.markdown("## Ответ на вопрос:")
                st.markdown(result_text)

                # Разделитель
                st.divider()

                # Выводим результат в сыром виде
                st.text_area(
                    "Ответ из этого поля скопируйте в грейдер:",
                    result_text,
                    height=50,
                )
            except Exception as e:
                st.error(f"Ошибка при вызове RPC функции: {str(e)}")
else:
    st.warning("Введите SUPABASE_URL и SUPABASE_KEY для подключения к Supabase.")
