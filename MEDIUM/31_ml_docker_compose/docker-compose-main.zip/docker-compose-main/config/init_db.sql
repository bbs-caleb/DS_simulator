CREATE TABLE IF NOT EXISTS submits (
    id UUID DEFAULT uuid_generate_v4(),
    submit_timestamp TIMESTAMP NOT NULL,
    user_id BIGINT NOT NULL,
    decision TEXT NOT NULL,
    amount FLOAT,
    PRIMARY KEY (id)
);
