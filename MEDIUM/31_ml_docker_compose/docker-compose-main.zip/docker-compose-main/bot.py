import logging
import os
from datetime import datetime

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    BotCommand,
)

import asyncio
import sys
from dotenv import load_dotenv
from src import utils
from src import db
from src import model


# Set up logging and load secrets
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stdout,
    format="%(asctime)s - %(message)s",
)
load_dotenv(".env", override=True)

# Init telegram bot and dispatcher
dp = Dispatcher()
form_router = Router()
dp.include_router(form_router)

token = os.getenv("BOT_TOKEN")
bot = Bot(token=token)

messages = utils.config("config/messages.yaml")


# Определение состояний для машины состояний
class CreditSurvey(StatesGroup):
    choosing_product = State()
    entering_amount = State()
    entering_income = State()


@form_router.message(Command("cancel"))
@form_router.message(F.text.casefold() == "cancel")
async def cancel_handler(message: Message, state: FSMContext) -> None:
    current_state = await state.get_state()
    if current_state is None:
        return

    logging.info(f"Cancelling state {current_state}")
    await state.clear()
    await message.answer(
        "Отмена заявки.",
        reply_markup=ReplyKeyboardRemove(),
    )


@form_router.message(CommandStart())
async def score(message: Message, state: FSMContext):
    await state.set_state(CreditSurvey.choosing_product)

    await message.answer(
        messages["product"]["question"].format(message.from_user.first_name),
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text=i)] for i in messages["product"]["options"]],
            resize_keyboard=True,
            one_time_keyboard=True,
        ),
    )


@form_router.message(CreditSurvey.choosing_product)
async def process_product(message: Message, state: FSMContext) -> None:
    product_dict = {
        "Кредит": "loan",
        "Кредитная карта": "card",
    }
    product = product_dict.get(message.text)
    await state.update_data(product=product)
    await state.set_state(CreditSurvey.entering_amount)
    await message.answer(messages["amount"]["question"])


@form_router.message(CreditSurvey.entering_amount)
async def process_amount(message: Message, state: FSMContext) -> None:
    await state.update_data(amount=message.text)
    await state.set_state(CreditSurvey.entering_income)
    await message.answer(messages["income"]["question"])


@form_router.message(CreditSurvey.entering_income)
async def process_income(message: Message, state: FSMContext) -> None:
    await state.update_data(income=message.text)
    await message.answer(messages["decision"]["loading"])

    user_id = message.from_user.id

    data = await state.get_data()
    product = data["product"]
    amount = data["amount"]

    logger.info(f"Data: {data}")
    decision = await model.run(data)
    logger.info(f"Decision: {decision}")

    await message.answer(messages["decision"][decision][product].format(amount))

    submit_data = {
        "submit_timestamp": datetime.now(),
        "user_id": user_id,
        "decision": decision,
        "amount": amount,
    }
    await db.insert_submit(submit_data)

    await state.clear()


# Long polling
async def main() -> None:
    logger.info("Starting bot...")

    await db.init_db_pool()

    menu = [
        BotCommand(
            command="start",
            description="Подать заявку на кредит/кредитную карту",
        ),
        BotCommand(
            command="cancel",
            description="Отменить текущее действие",
        ),
    ]
    await bot.set_my_commands(menu)

    await dp.start_polling(
        bot,
        skip_updates=True,
    )

    await db.close_db_pool()

    logger.info("Closing bot!")


if __name__ == "__main__":
    asyncio.run(main())
