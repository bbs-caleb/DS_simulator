import os
import asyncpg
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Global variable to hold the connection pool
pool = None


async def init_db_pool():
    global pool
    pool = await asyncpg.create_pool(
        user=os.getenv("POSTGRES_USER"),
        password=os.getenv("POSTGRES_PASSWORD"),
        database=os.getenv("POSTGRES_DB"),
        host=os.getenv("POSTGRES_HOST"),
        port=os.getenv("POSTGRES_PORT"),
        min_size=5,
        max_size=15,
    )
    logger.info("Database connection pool created!")


async def close_db_pool():
    global pool
    if pool:
        await pool.close()
        pool = None
        logger.info("Database connection pool closed!")


async def insert_submit(submit_data: Dict[str, Any]):
    # Establish a connection to the PostgreSQL database
    async with pool.acquire() as conn:
        try:
            # Insert a new submit into the submits table
            await conn.execute(
                """
                INSERT INTO submits (submit_timestamp, user_id, decision, amount)
                VALUES ($1, $2, $3, $4)
                """,
                submit_data["submit_timestamp"],
                submit_data["user_id"],
                submit_data["decision"],
                submit_data["amount"],
            )
            logger.info(f"Submit inserted: {submit_data}!")
        except Exception as e:
            # Log the error
            logger.error(f"Error inserting submit: {submit_data}!")
            logger.error(e)
