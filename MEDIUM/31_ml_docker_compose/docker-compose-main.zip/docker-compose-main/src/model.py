import random


async def run(data: dict) -> str:
    if random.choice([True, False]):
        return "approved"
    else:
        return "rejected"
